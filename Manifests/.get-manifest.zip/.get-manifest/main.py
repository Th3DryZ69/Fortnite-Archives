import os
import json
import time
import requests
from base64 import b64encode
import webbrowser

CLIENT_ID = '34a02cf8f4414e29b15921876da36f9a'
CLIENT_SECRET = 'daafbccc737745039dffe53d94fc76cf'

URLS = {
    'Android': '5cb97847cee34581afdbc445400e2f77/app/FortniteContentBuilds',
    'Android Shipping': '4fe75bbc5a674f4f9b356b5c90567da5/app/Fortnite',
    'IOS': '5cb97847cee34581afdbc445400e2f77/app/FortniteContentBuilds',
    'Windows': '4fe75bbc5a674f4f9b356b5c90567da5/app/Fortnite',
    'Windows Content': '5cb97847cee34581afdbc445400e2f77/app/FortniteContentBuilds',
    'Windows UEFN': '1e8bda5cfbb641b9a9aea8bd62285f73/app/Fortnite_Studio',
    'Switch': '5cb97847cee34581afdbc445400e2f77/app/FortniteContentBuilds',
    'Switch2': '5cb97847cee34581afdbc445400e2f77/app/FortniteContentBuilds',
    'PS4': '5cb97847cee34581afdbc445400e2f77/app/FortniteContentBuilds',
    'PS5': '5cb97847cee34581afdbc445400e2f77/app/FortniteContentBuilds',
    'XB1': '5cb97847cee34581afdbc445400e2f77/app/FortniteContentBuilds',
    'XSX': '5cb97847cee34581afdbc445400e2f77/app/FortniteContentBuilds',
}

ANDROID_BODY = {
    "abis": ["arm64-v8a", "armeabi-v7a", "armeabi"],
    "apiLevel": 30,
    "coreCount": 8,
    "hardwareName": "Qualcomm Technologies, Inc SDMMAGPIE",
    "hasLibHoudini": False,
    "machineId": "REDACTED",
    "manufacturer": "samsung",
    "memoryMiB": 5524,
    "model": "SM-A715F",
    "platform": "Android",
    "preInstallInfo": "ThirdPartyInstall",
    "renderingDevice": "Adreno (TM) 618",
    "renderingDriver": "OpenGL ES 3.2 V@0502.0",
    "sha1Fingerprint": "",
    "supportsArmNEON": True,
    "supportsFpRenderTargets": True,
    "textureCompressionFormats": ["ASTC", "ATC", "ETC2", "ETC1"],
    "version": "5.2.0"
}

# def get_access_token():
#     try:
#         auth = b64encode(f"{CLIENT_ID}:{CLIENT_SECRET}".encode()).decode()
#         resp = requests.post(
#             "https://account-public-service-prod03.ol.epicgames.com/account/api/oauth/token",
#             data={"grant_type": "client_credentials", "scope": "launcher:download:live:* READ"},
#             headers={
#                 "Authorization": f"Basic {auth}",
#                 "Content-Type": "application/x-www-form-urlencoded"
#             }
#         )
#         return resp.json()['access_token']
    
#     except Exception as e:
#         print(f"Token error: {e}")
#         return None

def get_access_token(code):
    try:
        auth = b64encode(f"{CLIENT_ID}:{CLIENT_SECRET}".encode()).decode()
        resp = requests.post(
            "https://account-public-service-prod03.ol.epicgames.com/account/api/oauth/token",
            data={"grant_type": "authorization_code", "code": code, "scope": "launcher:download:live:* READ"},
            headers={
                "Authorization": f"Basic {auth}",
                "Content-Type": "application/x-www-form-urlencoded"
            }
        )
        return resp.json()['access_token']
    
    except Exception as e:
        print(f"Token error: {e}")
        return None

def get_manifest(platform, token):
    plat = "Android" if platform.startswith("Android") else "Windows" if platform.startswith("Windows") else platform
    url = f"https://launcher-public-service-prod06.ol.epicgames.com/launcher/api/public/assets/v2/platform/{plat}/namespace/fn/catalogItem/{URLS[platform]}/label/Live"
    headers = {"Authorization": f"Bearer {token}"}

    try:
        if platform == "Android Shipping":
            resp = requests.post(url, headers=headers, json=ANDROID_BODY)
        else:
            resp = requests.get(url, headers=headers)

        if resp.status_code == 200:
            return resp.json()
        else:
            print(f"[{platform}] Failed request: {resp.status_code}")
            return None
    except Exception as e:
        print(f"Error fetching manifest for {platform}: {e}")
        return None

def save_manifest(platform, version, manifest_url, manifest_id):
    if platform == "Android":
        folder = "Manifests/Mobile/Android"
    elif platform == "Android Shipping":
        folder = "Manifests/Mobile/Android/Shipping"
    elif platform == "IOS":
        folder = "Manifests/Mobile/IOS"
    elif platform == "Windows":
        folder = "Manifests/Pc/Windows"
    elif platform == "Windows Content":
        folder = "Manifests/Pc/Windows/Content"
    elif platform == "Windows UEFN":
        folder = "Manifests/Pc/UEFN"
    elif platform == "Switch":
        folder = "Manifests/Console/Switch"
    elif platform == "Switch2":
        folder = "Manifests/Console/Switch2"
    elif platform == "PS4":
        folder = "Manifests/Console/PS4"
    elif platform == "PS5":
        folder = "Manifests/Console/PS5"
    elif platform == "XSX":
        folder = "Manifests/Console/XBoxSeriesX"
    elif platform == "XB1":
        folder = "Manifests/Console/XBoxOne"
    else:
        folder = os.path.join("manifests", platform.replace(" ", "_"))

    os.makedirs(folder, exist_ok=True)

    manifest_path = os.path.join(folder, f"{version}.manifest")
    if not os.path.exists(manifest_path):
        r = requests.get(manifest_url)
        if r.ok:
            with open(manifest_path, "wb") as f:
                f.write(r.content)
            print(f"[{platform}] Manifest downloaded: {manifest_path}")
        else:
            print(f"[{platform}] Failed to download manifest.")
    else:
        print(f"[{platform}] Manifest already exists, skipping download.")

    os.makedirs("Manifests/.manifest-id", exist_ok=True)
    txt_path = f"Manifests/.manifest-id/{platform}.txt"
    new_line = f"{version} = {manifest_id}\n"

    if os.path.exists(txt_path):
        with open(txt_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        if any(line.startswith(version) for line in lines):
            print(f"[{platform}] Version {version} already in txt, skipping write.")
            return version

    with open(txt_path, "a", encoding="utf-8") as f:
        f.write(new_line)
        print(f"[{platform}] Added version {version} to txt.")

    return version

def main():
    print("Ouverture du navigateur pour obtenir le code...")
    webbrowser.open("https://www.epicgames.com/id/api/redirect?clientId=34a02cf8f4414e29b15921876da36f9a&responseType=code")
    code = input("Collez ici le code de redirection Epic Games (dans l'URL après ?code=...): ")
    token = get_access_token(code)
    if not token:
        return

    latest = {}

    for platform in URLS:
        data = get_manifest(platform, token)
        if not data:
            continue

        elem = data.get("elements", [{}])[0]
        version = elem.get("buildVersion", "unknown")
        manifests = elem.get("manifests", [])
        if not manifests:
            continue

        m = manifests[1] if len(manifests) > 1 else manifests[0]
        path = m.get('uri')
        q = m.get('queryParams', [{}])[0]
        manifest_url = f"{path}?{q.get('name')}={q.get('value')}"
        manifest_id = path.split("/")[-1].replace(".manifest", "")

        latest[platform] = save_manifest(platform, version, manifest_url, manifest_id)
        time.sleep(1)

    with open("Manifests/.get-manifest/latest.json", "w", encoding="utf-8") as f:
        json.dump(latest, f, indent=4)
    print("✅ Fichier latest.json mis à jour.")

if __name__ == "__main__":
    main()
