@echo off
cd /d "%~dp0..\..\"
python "Manifests\.get-manifest\main.py"
pause